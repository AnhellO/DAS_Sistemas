# **LastFM playlist**

#### **Descripcion**

Programa que permite ver una lista de 100 artistas almacenada en la api lastfm (https://www.last.fm/home)
con diversos datos de dichos artistas.

#### **Instrucciones**
En la carpeta del proyecto ejecutar el comando: docker-compose up

Esperar a que se inicien los contenedores y los scripts finalizen, entonces podras ver desde el navegador con el siguiente enlance: localhost:5000 la aplicacion, desplazate atraves de ella desde la lista o desde la url localhost:5000/artist.

