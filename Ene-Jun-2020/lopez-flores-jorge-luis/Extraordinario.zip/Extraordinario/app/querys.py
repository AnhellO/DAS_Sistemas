class querys():

        def __init__(self):
            self.schema={
            'id':"",
            'name':"",
            'image':"",

        }